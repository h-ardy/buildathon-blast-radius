from __future__ import annotations

import typing as t
from decimal import Decimal

from sqlglot import exp, parser
from sqlglot.dialects.dialect import build_formatted_time, build_regexp_extract
from sqlglot.helper import seq_get
from sqlglot.parser import IsPredicatePrecedence
from sqlglot.tokens import TokenType

if t.TYPE_CHECKING:
    from sqlglot.dialects.dialect import Dialect


def build_with_ignore_nulls(
    exp_class: type[exp.Expr],
) -> t.Callable[[list[exp.Expr]], exp.Expr]:
    def _parse(args: list[exp.Expr]) -> exp.Expr:
        this = exp_class(this=seq_get(args, 0))
        if seq_get(args, 1) == exp.true():
            return exp.IgnoreNulls(this=this)
        return this

    return _parse


def _build_to_date(args: list, dialect: Dialect) -> exp.TsOrDsToDate:
    expr = build_formatted_time(exp.TsOrDsToDate)(args, dialect)
    expr.set("safe", True)
    return expr


def _build_named_struct(args: list) -> exp.Struct:
    """Map named_struct('k', v, ...) to exp.Struct so _annotate_struct sees it."""
    expressions: list[exp.Expression] = []
    for i in range(0, len(args) - 1, 2):
        key, value = args[i], args[i + 1]
        name = key.name
        expressions.append(exp.PropertyEQ(this=exp.to_identifier(name), expression=value))
    return exp.Struct(expressions=expressions)


def _build_date_add(args: list) -> exp.TsOrDsAdd:
    expression = seq_get(args, 1)
    if expression:
        expression = expression * -1

    return exp.TsOrDsAdd(
        this=seq_get(args, 0), expression=expression, unit=exp.Literal.string("DAY")
    )


class HiveParser(parser.Parser):
    IS_PREDICATE_PRECEDENCE = IsPredicatePrecedence.EQUALITY

    LOG_DEFAULTS_TO_LN = True
    STRICT_CAST = False
    VALUES_FOLLOWED_BY_PAREN = False
    JOINS_HAVE_EQUAL_PRECEDENCE = True
    ADD_JOIN_ON_TRUE = True
    ALTER_TABLE_PARTITIONS = True
    SUPPORTS_MULTI_PART_INTERVAL_ADD = True

    # Strip trailing fractional zeros and normalize zero when inferring BD literal types.
    NORMALIZE_DECIMAL_LITERALS = True

    # Allow negative scales for BD exponent literals, e.g. 1E3BD as DECIMAL(1, -3).
    DECIMAL_LITERALS_ALLOW_NEGATIVE_SCALE = False

    # Whether the dialect supports using ALTER COLUMN syntax with CHANGE COLUMN.
    CHANGE_COLUMN_ALTER_SYNTAX = False

    FUNCTION_PARSERS = {
        **parser.Parser.FUNCTION_PARSERS,
        "PERCENTILE": lambda self: self._parse_distinct_arg_function(exp.Quantile),
        "PERCENTILE_APPROX": lambda self: self._parse_distinct_arg_function(exp.ApproxQuantile),
    }

    FUNCTIONS = {
        **parser.Parser.FUNCTIONS,
        "BASE64": exp.ToBase64.from_arg_list,
        "COLLECT_LIST": lambda args: exp.ArrayAgg(this=seq_get(args, 0), nulls_excluded=True),
        "COLLECT_SET": exp.ArrayUniqueAgg.from_arg_list,
        "CONCAT_WS": lambda args, dialect: exp.ConcatWs(
            expressions=args,
            safe=not dialect.STRICT_STRING_CONCAT,
            coalesce=dialect.CONCAT_WS_COALESCE,
            flatten=True,
        ),
        "DATE_ADD": lambda args: exp.TsOrDsAdd(
            this=seq_get(args, 0), expression=seq_get(args, 1), unit=exp.Literal.string("DAY")
        ),
        "DATE_FORMAT": lambda args, dialect: build_formatted_time(exp.TimeToStr)(
            [
                exp.TimeStrToTime(this=seq_get(args, 0)),
                seq_get(args, 1),
            ],
            dialect,
        ),
        "DATE_SUB": _build_date_add,
        "DATEDIFF": lambda args: exp.DateDiff(
            this=exp.TsOrDsToDate(this=seq_get(args, 0)),
            expression=exp.TsOrDsToDate(this=seq_get(args, 1)),
        ),
        "DAY": lambda args: exp.Day(this=exp.TsOrDsToDate(this=seq_get(args, 0))),
        "FIRST": build_with_ignore_nulls(exp.First),
        "FIRST_VALUE": build_with_ignore_nulls(exp.FirstValue),
        "FROM_UNIXTIME": build_formatted_time(exp.UnixToStr, default=True),
        "GET_JSON_OBJECT": lambda args, dialect: exp.JSONExtractScalar(
            this=seq_get(args, 0), expression=dialect.to_json_path(seq_get(args, 1))
        ),
        "LAST": build_with_ignore_nulls(exp.Last),
        "LAST_VALUE": build_with_ignore_nulls(exp.LastValue),
        "MAP": parser.build_var_map,
        "MONTH": lambda args: exp.Month(this=exp.TsOrDsToDate.from_arg_list(args)),
        "NAMED_STRUCT": _build_named_struct,
        "REGEXP_EXTRACT": build_regexp_extract(exp.RegexpExtract),
        "REGEXP_EXTRACT_ALL": build_regexp_extract(exp.RegexpExtractAll),
        "SEQUENCE": exp.GenerateSeries.from_arg_list,
        "SIZE": exp.ArraySize.from_arg_list,
        "SPLIT": exp.RegexpSplit.from_arg_list,
        "STR_TO_MAP": lambda args: exp.StrToMap(
            this=seq_get(args, 0),
            pair_delim=seq_get(args, 1) or exp.Literal.string(","),
            key_value_delim=seq_get(args, 2) or exp.Literal.string(":"),
        ),
        "TO_DATE": _build_to_date,
        "TO_JSON": exp.JSONFormat.from_arg_list,
        "TRUNC": exp.TimestampTrunc.from_arg_list,
        "UNBASE64": exp.FromBase64.from_arg_list,
        "UNIX_TIMESTAMP": lambda args, dialect: build_formatted_time(exp.StrToUnix, default=True)(
            args or [exp.CurrentTimestamp()], dialect
        ),
        "YEAR": lambda args: exp.Year(this=exp.TsOrDsToDate.from_arg_list(args)),
    }

    NO_PAREN_FUNCTION_PARSERS = {
        **parser.Parser.NO_PAREN_FUNCTION_PARSERS,
        "TRANSFORM": lambda self: self._parse_transform(),
    }

    NO_PAREN_FUNCTIONS = {
        k: v for k, v in parser.Parser.NO_PAREN_FUNCTIONS.items() if k != TokenType.CURRENT_TIME
    }

    PROPERTY_PARSERS = {
        **parser.Parser.PROPERTY_PARSERS,
        "SERDEPROPERTIES": lambda self: exp.SerdeProperties(
            expressions=self._parse_wrapped_csv(self._parse_property)
        ),
        "USING": lambda self: self._parse_using_property(),
    }

    ALTER_PARSERS = {
        **parser.Parser.ALTER_PARSERS,
        "CHANGE": lambda self: self._parse_alter_table_change(),
        "REPLACE": lambda self: self._parse_alter_table_replace_columns(),
    }

    def build_cast(self, strict: bool, **kwargs) -> exp.Expr:
        if self._prev.text.upper() == "BD":
            this = kwargs["this"]
            _, digits, exponent = Decimal(this.name).as_tuple()
            precision, scale = len(digits), -int(exponent)

            if self.NORMALIZE_DECIMAL_LITERALS:
                if not any(digits):
                    precision, scale = 1, 0
                else:
                    while scale > 0 and digits[precision - 1] == 0:
                        precision -= 1
                        scale -= 1

            if scale < 0 and not self.DECIMAL_LITERALS_ALLOW_NEGATIVE_SCALE:
                precision -= scale
                scale = 0

            # Unsuffixed exponent literals can be DOUBLE, so cast from text to avoid rounding.
            kwargs["this"] = this if scale < 0 else exp.Literal.string(this.name)
            kwargs["to"] = exp.DataType(
                this=exp.DType.DECIMAL,
                expressions=[
                    exp.DataTypeParam(this=exp.Literal.number(value))
                    for value in (max(precision, scale), scale)
                ],
            )
        return super().build_cast(strict, **kwargs)

    def _parse_transform(self) -> exp.Transform | exp.QueryTransform | None:
        if not self._match(TokenType.L_PAREN, advance=False):
            self._retreat(self._index - 1)
            return None

        args = self._parse_wrapped_csv(self._parse_lambda)
        row_format_before = self._parse_row_format(match_row=True)

        record_writer = None
        if self._match_text_seq("RECORDWRITER"):
            record_writer = self._parse_string()

        if not self._match(TokenType.USING):
            return exp.Transform.from_arg_list(args)

        command_script = self._parse_string()

        self._match(TokenType.ALIAS)
        schema = self._parse_schema()

        row_format_after = self._parse_row_format(match_row=True)
        record_reader = None
        if self._match_text_seq("RECORDREADER"):
            record_reader = self._parse_string()

        return self.expression(
            exp.QueryTransform(
                expressions=args,
                command_script=command_script,
                schema=schema,
                row_format_before=row_format_before,
                record_writer=record_writer,
                row_format_after=row_format_after,
                record_reader=record_reader,
            )
        )

    def _parse_types(
        self,
        check_func: bool = False,
        schema: bool = False,
        allow_identifiers: bool = True,
        with_collation: bool = False,
    ) -> exp.Expr | None:
        """
        Spark (and most likely Hive) treats casts to CHAR(length) and VARCHAR(length) as casts to
        STRING in all contexts except for schema definitions. For example, this is in Spark v3.4.0:

            spark-sql (default)> select cast(1234 as varchar(2));
            23/06/06 15:51:18 WARN CharVarcharUtils: The Spark cast operator does not support
            char/varchar type and simply treats them as string type. Please use string type
            directly to avoid confusion. Otherwise, you can set spark.sql.legacy.charVarcharAsString
            to true, so that Spark treat them as string type as same as Spark 3.0 and earlier

            1234
            Time taken: 4.265 seconds, Fetched 1 row(s)

        This shows that Spark doesn't truncate the value into '12', which is inconsistent with
        what other dialects (e.g. postgres) do, so we need to drop the length to transpile correctly.

        Reference: https://spark.apache.org/docs/latest/sql-ref-datatypes.html
        """
        this = super()._parse_types(
            check_func=check_func,
            schema=schema,
            allow_identifiers=allow_identifiers,
            with_collation=with_collation,
        )

        if this and not schema:

            def _to_text(node: exp.Expr) -> exp.Expr:
                if isinstance(node, exp.DataType) and node.is_type("char", "varchar"):
                    node.set("this", exp.DType.TEXT)
                    node.set("expressions", None)
                return node

            return this.transform(_to_text, copy=False)

        return this

    def _parse_alter_table_change(self) -> exp.Expr | None:
        self._match(TokenType.COLUMN)
        this = self._parse_field(any_token=True)

        if self.CHANGE_COLUMN_ALTER_SYNTAX and self._match_text_seq("TYPE"):
            return self.expression(exp.AlterColumn(this=this, dtype=self._parse_types(schema=True)))

        column_new = self._parse_field(any_token=True)
        dtype = self._parse_types(schema=True)

        comment = self._match(TokenType.COMMENT) and self._parse_string()

        if not this or not column_new or not dtype:
            self.raise_error(
                "Expected 'CHANGE COLUMN' to be followed by 'column_name' 'column_name' 'data_type'"
            )

        return self.expression(
            exp.AlterColumn(this=this, rename_to=column_new, dtype=dtype, comment=comment)
        )

    def _parse_alter_table_replace_columns(self) -> exp.ReplaceColumns | None:
        if not self._match_text_seq("COLUMNS"):
            return None

        expressions = self._try_parse(
            lambda: self._parse_wrapped_csv(self._parse_field_def, optional=True)
        )
        return self.expression(exp.ReplaceColumns(expressions=expressions)) if expressions else None

    def _parse_using_property(self) -> exp.Property:
        if self._match_texts(("JAR", "FILE", "ARCHIVE")):
            kind = self._prev.text.upper()
            return exp.UsingProperty(this=self._parse_string(), kind=kind)

        return self._parse_property_assignment(exp.FileFormatProperty)

    def _parse_partition_and_order(
        self,
    ) -> tuple[list[exp.Expr], exp.Expr | None]:
        partition = (
            self._parse_csv(self._parse_assignment)
            if self._match(TokenType.DISTRIBUTE_BY)
            else self._parse_partition_by()
        )
        return partition, super()._parse_order(skip_order_token=self._match(TokenType.SORT_BY))

    def _parse_parameter(self) -> exp.Parameter:
        self._match(TokenType.L_BRACE)
        this = self._parse_identifier() or self._parse_primary_or_var()
        expression = self._match(TokenType.COLON) and (
            self._parse_identifier() or self._parse_primary_or_var()
        )
        self._match(TokenType.R_BRACE)
        return self.expression(exp.Parameter(this=this, expression=expression))

    def _to_prop_eq(self, expression: exp.Expr, index: int) -> exp.Expr:
        if expression.is_star:
            return expression

        if isinstance(expression, exp.Column):
            key = expression.this
        else:
            key = exp.to_identifier(f"col{index + 1}")

        return self.expression(exp.PropertyEQ(this=key, expression=expression))
